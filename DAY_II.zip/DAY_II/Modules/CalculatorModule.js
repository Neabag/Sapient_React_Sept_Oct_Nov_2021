// import * as MathModule from "./MathModule.js";

// import Addition, { Product } from "./MathModule.js";
// console.log("The addition is : " + Addition(70, 30));

// import { Add,Product } from "./MathModule.js";

// console.log("The addition is : " + Add(20, 30));
