function GetData() {
  return new Promise(function (resolve, reject) {
    var xmlhttpReq = new XMLHttpRequest();
    xmlhttpReq.open("GET", "https://jsonplaceholder.typicode.com/posts");
    xmlhttpReq.send(); // places the async call
    xmlhttpReq.onreadystatechange = function () {
      if (xmlhttpReq.status === 200 && xmlhttpReq.readyState === 4) {
        resolve(xmlhttpReq.responseText);
      } else if (xmlhttpReq.status !== 200 && xmlhttpReq.readyState === 4) {
        reject("Error : " + xmlhttpReq.status);
      }
    };
  });
}
