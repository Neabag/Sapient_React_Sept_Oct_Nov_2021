function GetData(callBack) {
  var xmlhttpReq = new XMLHttpRequest();
  xmlhttpReq.open("GET", "https://jsonplaceholder.typicode.com/postsss");
  xmlhttpReq.send(); // places the async call
  xmlhttpReq.onreadystatechange = function () {
    if (xmlhttpReq.status === 200 && xmlhttpReq.readyState === 4) {
      callBack(null, xmlhttpReq.responseText);
    } else if (xmlhttpReq.status !== 200 && xmlhttpReq.readyState === 4) {
      callBack("Error : " + xmlhttpReq.status, null);
    }
  };
}
