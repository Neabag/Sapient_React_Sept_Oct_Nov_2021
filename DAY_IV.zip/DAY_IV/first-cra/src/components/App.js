import React from "react";
import Product from "./product.component";
import "../styles/product.style.css";
import ProductWithBootstrap from "./product.withbootstrap";

class App extends React.Component {
  imageUrl =
    "https://repository-images.githubusercontent.com/37153337/9d0a6780-394a-11eb-9fd1-6296a684b124";
  products = [
    { name: "Mobile", price: 20000, offer: "10% off" },
    { name: "LED TV", price: 40000, offer: "10% off" },
    { name: "Laptop", price: 90000, offer: "10% off" },
  ];

  render() {
    var productsToBeCreated = this.products.map((product) => (
      <ProductWithBootstrap productdetails={product} />
    ));
    return (
      <div className="container">
        <img src={this.imageUrl} alt="react" height="100px" width="200px" />
        {/* <Product productdetails={this.productOne} />
        <Product productdetails={this.productTwo} />
        <Product productdetails={this.productThree} /> */}
        {/* <div className="product-card">{productsToBeCreated}</div> */}

        <div className="row">{productsToBeCreated}</div>
      </div>
    );
  }
}
export default App;
