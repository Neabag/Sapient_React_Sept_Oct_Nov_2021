import React from "react";
import "../styles/product.style.css";

class Product extends React.Component {
  render() {
    return (
      <div className="product-card-item">
        <h2>{this.props.productdetails.name}</h2>
        <strong>Price : {this.props.productdetails.price}</strong>
      </div>
    );
  }
}

export default Product;
