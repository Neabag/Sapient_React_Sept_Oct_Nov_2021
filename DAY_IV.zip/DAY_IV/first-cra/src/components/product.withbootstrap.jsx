import React from "react";
import "../styles/product.style.css";

class ProductWithBootstrap extends React.Component {
  render() {
    return (
      <div className="col-md-4">
        <h2>{this.props.productdetails.name}</h2>
        <strong>Price : {this.props.productdetails.price}</strong>
      </div>
    );
  }
}

export default ProductWithBootstrap;
