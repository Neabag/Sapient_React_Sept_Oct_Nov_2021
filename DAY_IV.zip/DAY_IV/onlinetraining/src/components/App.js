import InputMessage from "./inputmessage.component";
import ListOfCourses from "./listofcourses.component";

function App() {
  return (
    <div>
      <ListOfCourses />
      {/* <InputMessage /> */}
    </div>
  );
}

export default App;
