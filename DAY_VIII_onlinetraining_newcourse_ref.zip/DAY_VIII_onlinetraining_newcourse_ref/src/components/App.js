import InputMessage from "./inputmessage.component";
import ListOfCourses from "./listofcourses.component";
import Message from "./message.component";
import NewCourse from "./newcourse.component";
import Posts from "./posts.component";
import PostWithID from "./postswithid.component";
import { PostsWithuseEffect } from "./postswithuseEffect";
import Counter from "./useStateHook";

function App() {
  return (
    <div>
      {/* <Posts /> */}
      <ListOfCourses />
      {/* <InputMessage /> */}
      {/* <Counter /> */}
      {/* <PostsWithuseEffect /> */}
      {/* <PostWithID /> */}
      {/* <NewCourse /> */}
    </div>
  );
}

export default App;
