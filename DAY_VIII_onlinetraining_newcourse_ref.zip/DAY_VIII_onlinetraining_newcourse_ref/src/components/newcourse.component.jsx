import React, { useState } from "react";

export default function NewCourse() {
  const [newCourse, setNewCourse] = useState({});
  return (
    <form className="col-md-4">
      <h2>New Course</h2>
      <label htmlFor="txtCourseId">Id : </label>
      <input
        type="number"
        id="txtCourseId"
        className="form-control"
        onChange={(e) => setNewCourse({ ...newCourse, id: e.target.value })}
      />
      <label htmlFor="txtCourseTitle">Title : </label>
      <input
        type="text"
        id="txtCourseTitle"
        className="form-control"
        onChange={(e) => setNewCourse({ ...newCourse, title: e.target.value })}
      />
      <label htmlFor="txtCoursePrice">Price : </label>
      <input
        type="number"
        id="txtCoursePrice"
        className="form-control"
        onChange={(e) => setNewCourse({ ...newCourse, price: e.target.value })}
      />
      <label htmlFor="txtCourseRating">Rating : </label>
      <input
        type="number"
        id="txtCourseRating"
        className="form-control"
        onChange={(e) => setNewCourse({ ...newCourse, rating: e.target.value })}
      />
      <label htmlFor="txtCourseLikes">Likes : </label>
      <input
        type="number"
        id="txtCourseLikes"
        className="form-control"
        onChange={(e) => setNewCourse({ ...newCourse, likes: e.target.value })}
      />
      <label htmlFor="txtCourseImageUrl">Image : </label>
      <input
        type="text"
        id="txtCourseImageUrl"
        className="form-control"
        onChange={(e) =>
          setNewCourse({ ...newCourse, imageUrl: e.target.value })
        }
      />
      <input
        type="button"
        value="Add New Course"
        className="btn btn-success my-1"
      />
    </form>
  );
}
