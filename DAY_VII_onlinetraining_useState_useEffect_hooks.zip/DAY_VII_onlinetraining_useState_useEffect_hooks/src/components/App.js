import InputMessage from "./inputmessage.component";
import ListOfCourses from "./listofcourses.component";
import Message from "./message.component";
import Posts from "./posts.component";
import { PostsWithuseEffect } from "./postswithuseEffect";
import Counter from "./useStateHook";

function App() {
  return (
    <div>
      {/* <Posts /> */}
      <ListOfCourses />
      {/* <InputMessage /> */}
      {/* <Counter /> */}
      {/* <PostsWithuseEffect /> */}
    </div>
  );
}

export default App;
