import React from "react";
import "../styles/course.styles.css";
class Course extends React.Component {
  // state = { currLikes: this.props.coursedetails.likes };
  constructor(props) {
    super(props);
    this.state = { currLikes: this.props.coursedetails.likes };
    // this.IncrementLikes = this.IncrementLikes.bind(this);
  }
  IncrementLikes() {
    console.log("Within click.. Updating state..");
    // console.log(this.props.coursedetails.likes++); // readonly
    // state !
    // this.state.currLikes++; // state is immutable !
    this.setState({ currLikes: this.state.currLikes + 1 });
  }

  componentWillUnmount() {
    // clean up code !
    console.log("Inside componentWillUnmount :: Course");
  }

  render() {
    //console.log("Render :: Course");
    let ratings = [];
    for (let index = 0; index < this.props.coursedetails.rating; index++) {
      ratings.push(
        <i key={index} className="bi bi-star-fill text-warning"></i>
      );
    }
    return (
      <div className="col-md-3">
        <div className="card m-1">
          <img
            height="150px"
            width="200px"
            src={this.props.coursedetails.imageUrl}
            alt={this.props.coursedetails.name}
            className="card-img-top"
          />
          <div className="card-body">
            <p>{ratings}</p>
            <h5 className="card-title">{this.props.coursedetails.name}</h5>
            <h6 className="card-text">₹. {this.props.coursedetails.price}</h6>

            <p className="card-text"></p>

            {/* <button
              className="btn btn-outline-primary  btn-sm"
              onClick={this.IncrementLikes}
            > */}
            <button
              className="btn btn-outline-primary  btn-sm"
              onClick={() => this.IncrementLikes()}
            >
              <i className="bi bi-hand-thumbs-up-fill"></i>{" "}
              {/* {this.props.coursedetails.likes} */}
              {this.state.currLikes}
            </button>
            {/* <p className="card-text">{this.props.coursedetails.rating}</p> */}

            <button
              className="btn btn-outline-danger  btn-sm mx-2"
              onClick={() =>
                this.props.DeleteACourse(this.props.coursedetails.id)
              }
            >
              <i className="bi bi-trash2-fill"></i>
            </button>
          </div>
        </div>
      </div>
    );
  }
}

export default Course;
