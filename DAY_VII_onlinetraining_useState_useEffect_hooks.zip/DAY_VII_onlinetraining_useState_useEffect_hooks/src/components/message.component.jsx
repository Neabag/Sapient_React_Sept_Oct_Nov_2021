import React, { Component } from "react";

// export default class Message extends Component {
//   render() {
//     console.log("Render");
//     return <h1>{this.props.message}</h1>;
//   }
// }

function Message(props) {
  return <h1>{props.message}</h1>;
}

export default Message;
