import React, { Component } from "react";

export default class Posts extends Component {
  constructor(props) {
    super(props);
    this.state = { allPosts: [] };
  }
  async componentDidMount() {
    // fetch api using anonymous function (error - this)
    // fetch("https://jsonplaceholder.typicode.com/posts")
    //   .then((res) => res.json())
    //   .then(function (posts) {
    //     this.setState({ allPosts: posts });
    //   });
    // fetch api using arrow functions
    // fetch("https://jsonplaceholder.typicode.com/posts")
    //   .then((res) => res.json())
    //   .then((posts) => this.setState({ allPosts: posts }));
    // fetch api using async await
    try {
      let response = await fetch("https://jsonplaceholder.typicode.com/posts");
      let posts = await response.json();
      this.setState({ allPosts: posts });
    } catch (error) {
      console.log(error);
    }
  }
  render() {
    let allPostsTobeCreated = this.state.allPosts.map((post) => (
      <li key={post.id} className="list-group-item">
        {post.title}
      </li>
    ));

    var contenttoBeRendered;
    if (this.state.allPosts.length == 0) {
      contenttoBeRendered = (
        <img
          src="https://miro.medium.com/max/1400/1*CsJ05WEGfunYMLGfsT2sXA.gif"
          alt="Loading.."
        />
      );
    } else {
      contenttoBeRendered = (
        <ul className="list-group">{allPostsTobeCreated}</ul>
      );
    }
    return (
      <div>
        <h1>All Posts</h1>
        {contenttoBeRendered}
      </div>
    );
  }
}
