import { useState } from "react";
// available with 16.8+
var Counter = () => {
  const [count, setCount] = useState({ counter: 10 });
  const [age, setAge] = useState(20);
  return (
    <div>
      <p>Count : {count.counter}</p>
      <p>Age : {age}</p>

      <input
        type="button"
        value="Count++"
        onClick={() => setCount({ counter: count.counter + 1 })}
      />
      <input type="button" value="Age++" onClick={() => setAge(age + 1)} />
    </div>
  );
};

export default Counter;
// import React from "react";
// class Counter extends React.Component {
//   state = { count: 0, age: 20 };
//   incrementLikes() {
//     this.setState({ count: this.state.count + 1 });
//   }
//   render() {
//     return (
//       <div>
//         <p>Count : {this.state.count}</p>
//         <p>Age : {this.state.age}</p>

//         <input
//           type="button"
//           value="++"
//           onClick={this.incrementLikes.bind(this)}
//         />
//       </div>
//     );
//   }
// }
// export default Counter;
