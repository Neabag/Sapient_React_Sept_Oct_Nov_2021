import InputMessage from "./inputmessage.component";
import ListOfCourses from "./listofcourses.component";
import Posts from "./posts.component";

function App() {
  return (
    <div>
      <Posts />
      {/* <ListOfCourses /> */}
      {/* <InputMessage /> */}
    </div>
  );
}

export default App;
