import React, { Component } from "react";

export default class Posts extends Component {
  constructor(props) {
    super(props);
    this.state = { allPosts: [] };
  }
  async componentDidMount() {
    // fetch("https://jsonplaceholder.typicode.com/posts")
    //   .then((res) => res.json())
    //   .then((posts) => this.setState({ allPosts: posts }));
    try {
      let response = await fetch("https://jsonplaceholder.typicode.com/posts");
      let posts = await response.json();
      this.setState({ allPosts: posts });
    } catch (error) {
      console.log(error);
    }
  }
  render() {
    let allPostsTobeCreated = this.state.allPosts.map((post) => (
      <li key={post.id} className="list-group-item">
        {post.title}
      </li>
    ));
    return (
      <div>
        <h1>All Posts</h1>
        <p>
          {this.state.allPosts.length === 0 ? (
            <img
              src="https://miro.medium.com/max/1400/1*CsJ05WEGfunYMLGfsT2sXA.gif"
              alt="Loading.."
            />
          ) : (
            ""
          )}
        </p>
        <ul className="list-group">{allPostsTobeCreated}</ul>
      </div>
    );
  }
}
