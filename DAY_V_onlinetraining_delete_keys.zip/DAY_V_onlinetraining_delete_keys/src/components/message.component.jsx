import React, { Component } from "react";

export default class Message extends Component {
  render() {
    console.log("Render");
    return <h1>{this.props.message}</h1>;
  }
}
