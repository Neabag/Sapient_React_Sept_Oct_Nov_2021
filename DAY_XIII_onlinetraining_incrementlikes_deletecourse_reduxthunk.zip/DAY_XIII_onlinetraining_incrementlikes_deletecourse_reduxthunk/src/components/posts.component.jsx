import React, { useEffect } from "react";

export const Posts = (props) => {
  useEffect(() => {
    props.FetchPostAsync();
  }, []);
  let allPostsTobeCreated = props.allPosts.map((post) => (
    <li key={post.id} className="list-group-item">
      {post.title}
    </li>
  ));
  return (
    <div>
      <h1>All Posts</h1>
      <ul className="list-group">{allPostsTobeCreated}</ul>
    </div>
  );
};
