import ListOfCourses from "./listofcourses.component";

function App(props) {
  return (
    <div>
      <h1>Redux</h1>
      <ListOfCourses courses={props.allCourses} />
    </div>
  );
}

export default App;
