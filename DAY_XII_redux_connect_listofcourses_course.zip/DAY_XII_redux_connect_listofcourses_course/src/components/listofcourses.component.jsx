import React from "react";
import Course from "./course.component";

export default function ListOfCourses(props) {
  let coursesToBeCreated = props.courses.map((course) => (
    <Course key={course.id} coursedetails={course} {...props} />
  ));
  return (
    <div>
      <h1> List Of Courses</h1>
      <div className="row">{coursesToBeCreated}</div>
    </div>
  );
}
