export function courses(defStore = [], action) {
  switch (action.type) {
    case "INCREMENT_LIKES":
      console.log("Within Courses Reducer");
      console.log(action);
      return defStore; // should return a new store

    default:
      return defStore;
  }
}
