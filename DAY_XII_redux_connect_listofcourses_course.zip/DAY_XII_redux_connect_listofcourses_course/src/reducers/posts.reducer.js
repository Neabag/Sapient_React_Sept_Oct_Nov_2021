export function posts(defStore = [], action) {
  switch (action.type) {
    case "DELETE_POST":
      console.log("Within Posts Reducer");
      console.log(action);
      return defStore; // should return a new store
    default:
      return defStore;
  }
}
