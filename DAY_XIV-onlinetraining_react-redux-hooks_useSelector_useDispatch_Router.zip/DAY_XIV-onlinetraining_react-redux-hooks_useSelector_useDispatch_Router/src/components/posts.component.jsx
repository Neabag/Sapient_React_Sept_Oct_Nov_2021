import React, { useEffect } from "react";
import { Link } from "react-router-dom";

export const Posts = (props) => {
  useEffect(() => {
    props.FetchPostAsync();
  }, []);
  let allPostsTobeCreated = props.allPosts.map((post) => (
    <li key={post.id} className="list-group-item">
      <Link to={`/postdetails/${post.id}`}> {post.title}</Link>
    </li>
  ));
  return (
    <div>
      <h1>All Posts</h1>
      <ul className="list-group">{allPostsTobeCreated}</ul>
    </div>
  );
};
