import { DeletePost, IncrementLikes } from "./actions/actions";
import { DELETE_POST } from "./actions/types";

test("if action type is valid", () => {
  let action = DeletePost();
  expect(action.type).toBe(DELETE_POST);
});

test("if action is having correct payload", () => {
  let action = IncrementLikes(10);
  expect(action.theCourseId).toBe(10);
});
