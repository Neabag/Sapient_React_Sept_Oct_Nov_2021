// const INCREMENT_LIKES = "INCREMENT_LIKES";
import { DELETE_POST } from "./types";
export function IncrementLikes(theCourseId) {
  return { type: "INCREMENT_LIKES", theCourseId };
}

export function IncrementLikesAsync() {
  return { type: "INCREMENT_LIKES_ASYNC" };
}

export function DeleteCourse(theCourseId) {
  return { type: "DELETE_COURSE", theCourseId };
}

export function AddCourse(newcourse) {
  return { type: "ADD_COURSE", newcourse };
}

export function DeletePost() {
  return { type: DELETE_POST };
}

export function FetchAllPosts(posts) {
  return { type: "FETCH_POSTS", posts };
}

// saga
export function FetchPostAsync() {
  return { type: "FETCH_POSTS_ASYNC" };
}

// thunk
// export function FetchPostAsync() {
//   return (dispatch) => {
//     fetch("https://jsonplaceholder.typicode.com/posts")
//       .then((res) => res.json())
//       .then((posts) => {
//         console.log("Posts received !", posts);
//         dispatch(FetchAllPosts(posts));
//       });
//   };
// }

// Initial data -> []
// AJAX request to fetch data !
// when data arrives -> update that as store data !
