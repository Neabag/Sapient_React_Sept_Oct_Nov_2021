export const DELETE_POST = "DELETE_POST";
