// import ListOfCourses from "./listofcourses.component";
// import { Posts } from "./posts.component";
import { BrowserRouter, Routes, Link, Route } from "react-router-dom";
import PostDetails from "./postdetails.component";
import ListOfCourses_useSelector from "./listofcourses_useSelector";
import { lazy, Suspense } from "react";
const Posts = lazy(() => import("./posts.component"));

const loader = () => <strong>Loading...</strong>;

function App(props) {
  return (
    <BrowserRouter>
      <nav className="navbar navbar-expand-lg  navbar-dark bg-dark">
        <div className="container-fluid">
          <Link className="navbar-brand" to="/">
            Online Training
          </Link>
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarNavAltMarkup"
            aria-controls="navbarNavAltMarkup"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarNavAltMarkup">
            <div className="navbar-nav">
              <Link to="/" className="nav-link">
                Courses
              </Link>
              <Link to="/posts" className="nav-link">
                Posts
              </Link>
              <Link to="/newcourse" className="nav-link">
                New Course{" "}
              </Link>
              <Link to="/contextapi" className="nav-link">
                Context API{" "}
              </Link>
            </div>
          </div>
        </div>
      </nav>
      <Routes>
        {/* <Route
          path="/"
          element={<ListOfCourses courses={props.allCourses} {...props} />}
        ></Route> */}

        <Route path="/" element={<ListOfCourses_useSelector />}></Route>

        <Route
          path="/posts"
          element={
            <Suspense fallback={loader()}>
              <Posts />
            </Suspense>
          }
        ></Route>
        <Route
          path="/postdetails/:id"
          element={<PostDetails {...props} />}
        ></Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;

{
  /* <h1>Redux</h1>
      <ListOfCourses courses={props.allCourses} {...props} /> */
}
{
  /* <Posts {...props} /> */
}
