import React from "react";
import { useSelector } from "react-redux";
import { useParams } from "react-router";

export default function PostDetails(props) {
  const { id } = useParams();
  let allPosts = useSelector((state) => state.posts);

  // match the post with id param and render the data !
  let thePost = allPosts.find((p) => p.id === id);
  return (
    <div>
      <h2>Post Details for {id}</h2>
      <div>
        <h4> User Id : {thePost.userId} </h4>
        <h4> Id : {thePost.id} </h4>
        <h4> Title : {thePost.title} </h4>
        <h4> Body : {thePost.body} </h4>
      </div>
    </div>
  );
}
