import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Link } from "react-router-dom";

const Posts = (props) => {
  let dispatch = useDispatch();
  let allPosts = useSelector((state) => state.posts);

  useEffect(() => {
    // props.FetchPostAsync();
    // dispatch({ type: "FETCH_POSTS_ASYNC" });
  }, []);
  let allPostsTobeCreated = allPosts.map((post) => (
    <li key={post.id} className="list-group-item">
      <Link to={`/postdetails/${post.id}`}> {post.title}</Link>
    </li>
  ));
  return (
    <div>
      <h1>All Posts</h1>
      <button onClick={() => dispatch({ type: "FETCH_POSTS_ASYNC" })}>
        Get Posts
      </button>
      <ul className="list-group">{allPostsTobeCreated}</ul>
    </div>
  );
};

export default Posts;
