import React from "react";

export default function TotalCourses(props) {
  return (
    <div>
      <button className="btn btn-warning">
        Total Courses : ({props.count})
      </button>
    </div>
  );
}
