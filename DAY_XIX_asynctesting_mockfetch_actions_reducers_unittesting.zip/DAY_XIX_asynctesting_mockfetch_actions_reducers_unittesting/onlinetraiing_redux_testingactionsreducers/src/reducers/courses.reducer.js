let index;
let theCourseId;
export function courses(defStore = [], action) {
  switch (action.type) {
    case "INCREMENT_LIKES":
      console.log("Within Courses Reducer");
      console.log(action);
      console.log(defStore);
      theCourseId = action.theCourseId;
      index = defStore.findIndex((c) => c.id === theCourseId);
      return [
        ...defStore.slice(0, index),
        { ...defStore[index], likes: defStore[index].likes + 1 },
        ...defStore.slice(index + 1),
      ];

    case "DELETE_COURSE":
      theCourseId = action.theCourseId;
      index = defStore.findIndex((c) => c.id === theCourseId);
      return [...defStore.slice(0, index), ...defStore.slice(index + 1)];

    case "ADD_COURSE":
      return [...defStore, action.newcourse];

    default:
      return defStore;
  }
}

// [
//   { id: 1, title: "xyz" },
//   { id: 2, title: "csid" },
//   { id: 3, title: "xzsas" },
// ];
