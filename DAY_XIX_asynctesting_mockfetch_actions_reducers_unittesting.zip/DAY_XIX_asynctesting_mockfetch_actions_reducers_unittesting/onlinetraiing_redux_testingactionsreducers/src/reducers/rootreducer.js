import { combineReducers } from "redux";
import { courses } from "./courses.reducer";
import { posts } from "./posts.reducer";
var rootReducer = combineReducers({ courses, posts });
export default rootReducer;
