import React from "react";
import { render, unmountComponentAtNode } from "react-dom";
import GetPostWithID from "./getpostbyid";
import { act } from "react-dom/test-utils";

describe("mocking of fetch api/async call", () => {
  let container = null;

  beforeEach(() => {
    // setup before each test
    container = document.createElement("div");
    document.body.appendChild(container);
  });

  afterEach(() => {
    // clean up
    unmountComponentAtNode(container);
    container.remove();
    container = null;
  });

  it("renders post data", async () => {
    const fakePost = {
      userId: 1,
      id: 1,
      title:
        "sunt aut facere repellat provident occaecati excepturi optio reprehenderit",
      body: "quia et suscipit\nsuscipit recusandae consequuntur expedita et cum\nreprehenderit molestiae ut ut quas totam\nnostrum rerum est autem sunt rem eveniet architecto",
    };

    jest
      .spyOn(global, "fetch")
      .mockImplementation(() =>
        Promise.resolve({ json: () => Promise.resolve(fakePost) })
      );

    await act(async () => {
      render(<GetPostWithID />, container);
    });

    expect(container.querySelector("h3").textContent).toEqual(fakePost.title);
  });
});
