function App() {
  return (
    <div className="App">
      <h1>Redux</h1>
    </div>
  );
}

export default App;
