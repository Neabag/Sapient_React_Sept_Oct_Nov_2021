export function courses(defStore = [], action) {
  console.log("Within Courses Reducer");

  return defStore; // should return a new store
}
