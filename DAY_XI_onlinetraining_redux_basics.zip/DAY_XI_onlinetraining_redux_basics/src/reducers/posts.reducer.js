export function posts(defStore = [], action) {
  console.log("Within Posts Reducer");

  return defStore; // should return a new store
}
