import App from "./App";
import Enzyme, { shallow } from "enzyme";
import Adapter from "enzyme-adapter-react-16";

Enzyme.configure({ adapter: new Adapter() });

describe("state of counter", () => {
  it("counter is zero", () => {
    let appInstance = shallow(<App />); // generates the DOM for App
    let count = appInstance.state().count;
    expect(count).toBe(0);
  });

  it("counter increments to 1", () => {
    let appInstance = shallow(<App />); // generates the DOM for App
    let btn = appInstance.find("button");
    btn.simulate("click");
    let ptext = appInstance.find("p").text();
    expect(ptext).toEqual(" Counter : 1");
  });
});
