import React from "react";
import Course from "./course.component";
import TotalCourses from "./totalcourses.component";

export default function ListOfCourses(props) {
  let coursesToBeCreated = props.courses.map((course) => (
    <Course key={course.id} coursedetails={course} {...props} />
  ));
  return (
    <div>
      <h1> List Of Courses</h1>
      <TotalCourses count={props.allCourses.length} />
      <div className="row">{coursesToBeCreated}</div>
    </div>
  );
}
