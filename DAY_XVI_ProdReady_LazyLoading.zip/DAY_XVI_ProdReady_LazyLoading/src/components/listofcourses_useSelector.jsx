import React from "react";
import { useSelector } from "react-redux";
import Course from "./course.component";
import TotalCourses from "./totalcourses.component";

export default function ListOfCourses_useSelector() {
  const courses = useSelector((state) => state.courses);

  let coursesToBeCreated = courses.map((course) => (
    <Course key={course.id} coursedetails={course} />
  ));
  return (
    <div>
      <h1> List Of Courses - Use Selector</h1>
      <TotalCourses count={courses.length} />
      <div className="row">{coursesToBeCreated}</div>
    </div>
  );
}
