import { takeEvery, delay, put, call, retry } from "redux-saga/effects";
import axios from "axios";
export function* fetch_posts_async() {
  let response = yield call(
    axios.get,
    "https://jsonplaceholder.typicode.com/posts"
  );
  yield put({ type: "FETCH_POSTS", posts: response.data }); // dispatch an action
}

export function* incrementLikes() {
  yield delay(3000);
  yield put({ type: "INCREMENT_LIKES", theCourseId: 1 }); // dispatch an action
}

function CallPosts() {
  return axios.get("https://jsonplaceholder.typicode.com/posts");
}

export function* fetch_posts_async_retry() {
  try {
    let duration = 1000;
    let response = yield retry(3, duration * 10, CallPosts);
    yield put({ type: "FETCH_POSTS", posts: response.data });
  } catch (error) {
    console.log(error);
  }
}

// watcher
export function* mySaga() {
  yield takeEvery("INCREMENT_LIKES_ASYNC", incrementLikes);
  //   yield takeEvery("FETCH_POSTS_ASYNC", fetch_posts_async);
  yield takeEvery("FETCH_POSTS_ASYNC", fetch_posts_async_retry);
}
