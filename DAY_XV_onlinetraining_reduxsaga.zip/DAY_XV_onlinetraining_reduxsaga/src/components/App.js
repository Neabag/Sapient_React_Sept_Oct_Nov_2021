import ListOfCourses from "./listofcourses.component";
import { Posts } from "./posts.component";
import { BrowserRouter, Routes, Link, Route } from "react-router-dom";
import PostDetails from "./postdetails.component";
import ListOfCourses_useSelector from "./listofcourses_useSelector";

function App(props) {
  return (
    <BrowserRouter>
      <Routes>
        {/* <Route
          path="/"
          element={<ListOfCourses courses={props.allCourses} {...props} />}
        ></Route> */}

        <Route path="/" element={<ListOfCourses_useSelector />}></Route>

        <Route path="/posts" element={<Posts {...props} />}></Route>
        <Route
          path="/postdetails/:id"
          element={<PostDetails {...props} />}
        ></Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;

{
  /* <h1>Redux</h1>
      <ListOfCourses courses={props.allCourses} {...props} /> */
}
{
  /* <Posts {...props} /> */
}
