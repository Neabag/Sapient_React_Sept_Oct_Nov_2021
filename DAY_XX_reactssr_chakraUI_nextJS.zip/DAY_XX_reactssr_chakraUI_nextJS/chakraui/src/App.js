import logo from "./logo.svg";
import "./App.css";
import { VStack, HStack, Heading, IconButton } from "@chakra-ui/react";
import { FaReact } from "react-icons/fa";

function App() {
  return (
    <VStack>
      <Heading as="h1">Using Chakra UI</Heading>
      <Heading as="h2">Creating app using Chakra UI</Heading>
      <HStack>
        <IconButton icon={<FaReact />} size="lg" isRound="true" ></IconButton>
        <IconButton icon={<FaReact />} size="lg" isRound="true"></IconButton>
        <IconButton icon={<FaReact />} size="lg" isRound="true"></IconButton>
        <IconButton icon={<FaReact />} size="lg" isRound="true"></IconButton>
      </HStack>
    </VStack>
  );
}

export default App;
