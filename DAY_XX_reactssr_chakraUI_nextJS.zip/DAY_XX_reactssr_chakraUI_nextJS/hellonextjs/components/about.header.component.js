import React from "react";

function AboutHeader() {
  return (
    <div>
      <h1> This is the About Header component !</h1>
    </div>
  );
}

export default AboutHeader;
