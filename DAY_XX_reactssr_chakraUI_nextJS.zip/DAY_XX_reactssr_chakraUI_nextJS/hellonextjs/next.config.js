module.exports = {
  reactStrictMode: true,
  presets: ["next/babel"],
};
