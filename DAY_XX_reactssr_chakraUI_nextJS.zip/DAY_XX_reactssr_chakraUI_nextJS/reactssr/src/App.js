import logo from "./logo.svg";
import "./App.css";
import React from "react";

function App() {
  return (
    <div className="App">
      <h1>This is Server side Rendered App !</h1>
    </div>
  );
}

export default App;
