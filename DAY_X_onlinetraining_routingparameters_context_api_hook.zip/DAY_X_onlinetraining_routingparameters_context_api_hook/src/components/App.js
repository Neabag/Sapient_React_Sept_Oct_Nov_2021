import InputMessage from "./inputmessage.component";
import ListOfCourses from "./listofcourses.component";
import Message from "./message.component";
import NewCourse from "./newcourse.component";
import NewCourseReactHookForm from "./newcourse_reacthookform";
import Posts from "./posts.component";
import PostWithID from "./postswithid.component";
import { PostsWithuseEffect } from "./postswithuseEffect";
import Counter from "./useStateHook";
import { BrowserRouter, Switch, Route, Link, Redirect } from "react-router-dom";
import React, { Fragment } from "react";
import PostDetails from "./postdetails.component";
import { GrandParent } from "./contextapi";

function App() {
  return (
    <BrowserRouter>
      {/* <a href="/">Courses </a> | <a href="/posts">Posts </a> |{" "}
      <a href="/newcourse">New Course </a> */}
      {/* <Link to="/">Courses</Link> | <Link to="/posts">Posts</Link> |{" "}
      <Link to="/newcourse">New Course </Link> */}
      <nav className="navbar navbar-expand-lg  navbar-dark bg-dark">
        <div className="container-fluid">
          <Link className="navbar-brand" to="/">
            Online Training
          </Link>
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarNavAltMarkup"
            aria-controls="navbarNavAltMarkup"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarNavAltMarkup">
            <div className="navbar-nav">
              <Link to="/" className="nav-link">
                Courses
              </Link>
              <Link to="/posts" className="nav-link">
                Posts
              </Link>
              <Link to="/newcourse" className="nav-link">
                New Course{" "}
              </Link>
              <Link to="/contextapi" className="nav-link">
                Context API{" "}
              </Link>
            </div>
          </div>
        </div>
      </nav>
      <Switch>
        <Route path="/" component={ListOfCourses} exact></Route>
        <Route path="/posts" component={Posts}></Route>
        <Route path="/postdetails/:pid" component={PostDetails}></Route>
        <Route path="/contextapi" component={GrandParent}></Route>

        <Route path="/newcourse" component={NewCourseReactHookForm}></Route>
        {/* <Route
          path="**"
          render={() => (
            <Fragment>
              <img
                src="http://www.setra.com/hubfs/Sajni/crc_error.jpg"
                alt="Error !"
                height="200px"
                width="200px"
              />
              <h1 style={{ color: "red" }}>Resource not found !</h1>
            </Fragment>
          )}
        ></Route> */}
        <Route path="**" render={() => <Redirect to="/" />}></Route>
      </Switch>
    </BrowserRouter>
  );
}

export default App;
