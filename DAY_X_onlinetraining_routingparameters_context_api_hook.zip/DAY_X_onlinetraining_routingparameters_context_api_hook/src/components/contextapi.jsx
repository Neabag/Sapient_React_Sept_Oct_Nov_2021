import React, { useContext } from "react";
var MsgContext = React.createContext();

export class MsgProvider extends React.Component {
  constructor(props) {
    super(props);
    this.state = { msg: "Hello !" };
  }
  render() {
    return (
      <MsgContext.Provider
        value={{
          msgState: this.state,
          sayHi: () => this.setState({ msg: "Hi" }),
        }}
      >
        {this.props.children}
      </MsgContext.Provider>
    );
  }
}

export class GrandParent extends React.Component {
  render() {
    return (
      <MsgProvider>
        <Parent></Parent>
      </MsgProvider>
    );
  }
}

export class Parent extends React.Component {
  render() {
    return (
      <>
        {/* <Child></Child> */}
        <ChildASFunctional></ChildASFunctional>
        <AnotherChild></AnotherChild>
      </>
    );
  }
}

export class AnotherChild extends React.Component {
  render() {
    return (
      <div>
        {" "}
        <h2> Another Child ! </h2>
        <MsgContext.Consumer>
          {(message) => (
            <div>Message from GrandParent : {message.msgState.msg}</div>
          )}
        </MsgContext.Consumer>
      </div>
    );
  }
}
// export class Child extends React.Component {
//   render() {
//     return (
//       <MsgContext.Consumer>
//         {(message) => (
//           <div>
//             <h2>Child</h2>
//             Message from GrandParent : {message.msgState.msg}
//             <button onClick={() => message.sayHi()}>Say hi !</button>
//           </div>
//         )}
//       </MsgContext.Consumer>
//     );
//   }
// }
// Functional way !
export function ChildASFunctional() {
  const msgContext = useContext(MsgContext);
  return (
    <div>
      <h2>Child </h2>
      <p>Message from GrandParent is : {msgContext.msgState.msg}</p>
    </div>
  );
}
