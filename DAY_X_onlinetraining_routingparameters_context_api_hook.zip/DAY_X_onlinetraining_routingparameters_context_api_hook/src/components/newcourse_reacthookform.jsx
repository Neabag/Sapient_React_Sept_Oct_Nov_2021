import React from "react";
import { useForm } from "react-hook-form";

export default function NewCourseReactHookForm(props) {
  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm();
  return (
    <div className="col-md-4">
      <form
        onSubmit={handleSubmit((formdata) => {
          //   console.log(formdata);
          let newCourse = {
            id: formdata.CourseId,
            name: formdata.CourseName,
            imageUrl: formdata.CourseImage,
          };
          props.AddNewCourse(newCourse);
          //   reset()
        })}
      >
        <h2>New Course</h2>
        <label htmlFor="txtCourseId">
          {" "}
          <span style={{ color: "red" }}>*</span> Id :{" "}
        </label>
        <input
          type="number"
          id="txtCourseId"
          className="form-control"
          {...register("CourseId", { required: "The Course Id is required !" })}
        />
        {errors.CourseId && (
          <p style={{ color: "red" }}>{errors.CourseId.message}</p>
        )}

        <label htmlFor="txtCourseName">
          {" "}
          <span style={{ color: "red" }}>*</span> Name :{" "}
        </label>
        <input
          type="text"
          id="txtCourseName"
          className="form-control"
          {...register("CourseName", {
            required: "The Course Name is required !",
            maxLength: {
              value: 10,
              message: "You exceeded max length 10 chars",
            },
            // validate:validatorFunction
          })}
        />

        <label htmlFor="txtCourseImage">
          {" "}
          <span style={{ color: "red" }}>*</span> Name :{" "}
        </label>
        <input
          type="text"
          id="txtCourseImage"
          className="form-control"
          {...register("CourseImage", {
            required: "Image is required !",
          })}
        />

        {errors.CourseName && (
          <p style={{ color: "red" }}>{errors.CourseName.message}</p>
        )}

        <input
          type="submit"
          value="Add New Course"
          className="btn btn-success my-1"
        />
      </form>
    </div>
  );
}
