import React, { useState, useEffect } from "react";

export default function PostDetails(props) {
  console.log(props);
  const [thePost, setPost] = useState({});
  const {
    match: { params },
  } = props;
  useEffect(() => {
    fetch("https://jsonplaceholder.typicode.com/posts/" + params.pid)
      .then((res) => res.json())
      .then((responsePost) => setPost(responsePost));
  }, []);
  return (
    <div>
      <h2>Post Details for {params.pid}</h2>
      <div>
        <h4> User Id : {thePost.userId} </h4>
        <h4> Id : {thePost.id} </h4>
        <h4> Title : {thePost.title} </h4>
        <h4> Body : {thePost.body} </h4>
      </div>

      <button
        className="btn btn-primary"
        onClick={() => props.history.goBack()}
      >
        Back
      </button>
    </div>
  );
}
