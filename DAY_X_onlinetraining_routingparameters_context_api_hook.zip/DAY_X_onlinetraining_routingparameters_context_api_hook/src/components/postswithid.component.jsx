import React, { useEffect, useState, useRef } from "react";

export default function PostWithID() {
  let [postData, setPostData] = useState({ title: "" });
  let [postId, setPostId] = useState(1);
  const textInput = useRef(null);
  useEffect(
    () =>
      fetch("https://jsonplaceholder.typicode.com/posts/" + postId)
        .then((res) => res.json())
        .then((responsePost) => setPostData(responsePost)),
    [postId]
  );

  return (
    <div>
      <label htmlFor="txtPostId">Enter Post Id : </label>{" "}
      <input
        type="text"
        id="txtPostId"
        // ref={textInput}

        onChange={(e) => setPostId(e.target.value)}
      />
      <input
        type="button"
        value="Get Post Data !"
        onClick={() => setPostId(textInput.current.value)}
      />
      <hr />
      <h2>Details for : {postId}</h2>
      <div id="postTitle">{postData.title}</div>
    </div>
  );
}
