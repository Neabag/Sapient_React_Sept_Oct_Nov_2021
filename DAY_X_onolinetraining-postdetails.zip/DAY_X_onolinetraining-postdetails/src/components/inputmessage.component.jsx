import React, { Component } from "react";
import Message from "./message.component";

export default class InputMessage extends Component {
  state = { msg: "" };
  render() {
    return (
      <div>
        <label htmlFor="txtMessage">Message : </label>
        <input
          type="text"
          id="txtMessage"
          onChange={(e) => this.setState({ msg: e.target.value })}
        />
        <Message message={this.state.msg} />
      </div>
    );
  }
}
