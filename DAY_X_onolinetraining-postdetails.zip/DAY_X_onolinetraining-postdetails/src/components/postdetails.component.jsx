import React from "react";

export default function PostDetails() {
  return (
    <div>
      <h2>Post Details</h2>
    </div>
  );
}
