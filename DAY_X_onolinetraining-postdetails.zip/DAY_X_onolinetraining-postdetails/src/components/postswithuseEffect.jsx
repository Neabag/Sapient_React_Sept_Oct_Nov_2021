import React, { useEffect, useState } from "react";

export const PostsWithuseEffect = () => {
  const [posts, setPosts] = useState([]);
  useEffect(() => {
    fetch("https://jsonplaceholder.typicode.com/posts")
      .then((res) => res.json())
      .then((responsePosts) => setPosts(responsePosts));
  }, []);
  let allPostsTobeCreated = posts.map((post) => (
    <li key={post.id} className="list-group-item">
      {post.title}
    </li>
  ));
  return (
    <div>
      <h1>All Posts</h1>
      <ul className="list-group">{allPostsTobeCreated}</ul>
    </div>
  );
};
