import ListOfCourses from "./listofcourses.component";

function App() {
  return (
    <div>
      <ListOfCourses />
    </div>
  );
}

export default App;
